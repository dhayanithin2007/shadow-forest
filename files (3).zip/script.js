// NILA Shadow Forest — chess rules come from chess.js, everything else is here.
const $ = s => document.querySelector(s);
const wait = ms => new Promise(r => setTimeout(r, ms));
const rnd = (a, b) => a + Math.random() * (b - a);

const GLYPH = { k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟" };
const NAMES = { k: "King", q: "Queen", r: "Rook", b: "Bishop", n: "Knight", p: "Pawn" };
const VERBS = { p: "strikes", n: "slashes", b: "blasts", r: "crushes", q: "obliterates", k: "smites" };
const VALUE = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 20000 };
const FX = {
  p: ["slash"], n: ["slash", "slash slash2"], b: ["beam", "burst"],
  r: ["shock", "shock shock2", "burst"], q: ["burst big", "ring", "burst"], k: ["ring gold", "slash", "burst"]
};

let game;
const state = { mode: "ai", flipped: false, sel: null, moves: [], busy: false, sound: true, last: null, anim: null, gen: 0 };

import("https://cdn.jsdelivr.net/npm/chess.js@1.4.0/+esm")
  .then(mod => { game = new mod.Chess(); init(); })
  .catch(() => {
    $("#statusTitle").textContent = "Could not load chess.js";
    $("#statusText").textContent = "Check your internet connection and reload the page.";
  });

function init() {
  buildForest();
  $("#board").addEventListener("click", e => {
    const sq = e.target.closest(".sq");
    if (sq) onSquare(sq.dataset.sq);
  });
  setupDrag();
  document.querySelectorAll("[data-mode]").forEach(b => b.addEventListener("click", () => {
    sfx.click();
    state.mode = b.dataset.mode;
    document.querySelectorAll("[data-mode]").forEach(x => {
      x.classList.toggle("on", x === b);
      x.setAttribute("aria-pressed", x === b);
    });
    newGame();
  }));
  $("#newBtn").onclick = () => { sfx.click(); newGame(); };
  $("#endNew").onclick = () => { sfx.click(); newGame(); };
  $("#endClose").onclick = () => { $("#end").hidden = true; };
  $("#undoBtn").onclick = () => { sfx.click(); undo(); };
  $("#flipBtn").onclick = () => {
    if (state.busy) return;
    sfx.click(); state.flipped = !state.flipped; clearSel(); renderAll();
  };
  $("#soundBtn").onclick = () => {
    state.sound = !state.sound;
    $("#soundBtn").textContent = state.sound ? "SOUND ON" : "SOUND OFF";
    $("#soundBtn").setAttribute("aria-pressed", state.sound);
    sfx.click();
  };
  renderAll();
}

/* ---------- coordinates ---------- */
// column/row of a square as it is drawn (row 0 = top of the screen)
function disp(sq) {
  const f = "abcdefgh".indexOf(sq[0]), r = 8 - +sq[1];
  return state.flipped ? [7 - f, 7 - r] : [f, r];
}
const humanTurn = () => state.mode === "two" || game.turn() === "w";

/* ---------- rendering ---------- */
function renderBoard() {
  const el = $("#board");
  el.textContent = "";
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    const f = state.flipped ? 7 - c : c, rank = state.flipped ? r + 1 : 8 - r;
    const sq = "abcdefgh"[f] + rank;
    const d = document.createElement("div");
    d.className = "sq " + ((f + rank) % 2 ? "dark" : "light");
    d.dataset.sq = sq;
    if (c === 0) d.insertAdjacentHTML("beforeend", `<span class="co r">${rank}</span>`);
    if (r === 7) d.insertAdjacentHTML("beforeend", `<span class="co f">${"abcdefgh"[f]}</span>`);
    let p = game.get(sq);
    if (state.anim && state.anim.hide.has(sq)) p = state.anim.show[sq] || null;
    if (p) {
      const pc = document.createElement("span");
      pc.className = `pc ${p.color}`;
      pc.textContent = GLYPH[p.type] + "\uFE0E";
      pc.draggable = true;
      pc.style.animationDelay = `${-rnd(0, 4)}s`;
      d.append(pc);
    }
    el.append(d);
  }
  mark();
}

// toggles highlight classes without rebuilding the board (keeps drag alive)
function mark() {
  const king = game.isCheck() ? findKing(game.turn()) : null;
  document.querySelectorAll(".sq").forEach(d => {
    const sq = d.dataset.sq, m = state.moves.find(x => x.to === sq);
    d.classList.toggle("sel", sq === state.sel);
    d.classList.toggle("target", !!m);
    d.classList.toggle("capture", !!m && !!m.captured);
    d.classList.toggle("last", !!state.last && state.last.includes(sq));
    d.classList.toggle("check", sq === king);
  });
}

function findKing(color) {
  for (const row of game.board()) for (const p of row) if (p && p.type === "k" && p.color === color) return p.square;
}

function renderAll() { renderBoard(); updatePanel(); }

function updatePanel() {
  const t = game.turn(), over = game.isGameOver(), ai = state.mode === "ai";
  $("#turn").textContent = over ? "GAME OVER" : (t === "w" ? "WHITE TO MOVE" : "BLACK TO MOVE");

  let title, text;
  if (game.isCheckmate()) { title = "Checkmate"; text = `${t === "w" ? "Black" : "White"} wins the battle.`; }
  else if (game.isStalemate()) { title = "Stalemate"; text = "No legal moves left. The forest falls silent."; }
  else if (game.isDraw()) { title = "Draw"; text = "Neither side can win this battle."; }
  else {
    title = ai ? (t === "w" ? "Your move" : "NILA's move") : (t === "w" ? "White's move" : "Black's move");
    text = game.isCheck() ? "King under attack! Save your king." : (ai && t === "b" ? "NILA is plotting her strike." : "Select a piece to see its legal moves.");
  }
  $("#statusTitle").textContent = title;
  $("#statusText").textContent = text;

  // history
  const hist = game.history(), ol = $("#history");
  ol.textContent = "";
  for (let i = 0; i < hist.length; i += 2) {
    const li = document.createElement("li");
    const cur = n => (n === hist.length - 1 ? " cur" : "");
    li.innerHTML = `<span class="n">${i / 2 + 1}.</span><span class="m${cur(i)}">${hist[i]}</span><span class="m${cur(i + 1)}">${hist[i + 1] || ""}</span>`;
    ol.append(li);
  }
  ol.scrollTop = ol.scrollHeight;

  // player cards + captures
  const caps = { w: [], b: [] };
  for (const m of game.history({ verbose: true })) if (m.captured) caps[m.color].push(m.captured);
  const bottom = state.flipped ? "b" : "w";
  [["#cardBottom", bottom], ["#cardTop", bottom === "w" ? "b" : "w"]].forEach(([id, color]) => {
    const card = $(id);
    const [name, role] = ai ? (color === "w" ? ["YOU", "White — Rune Knight"] : ["NILA BOT", "Black — Shadow Mage"])
                            : (color === "w" ? ["PLAYER 1", "White — Rune Knight"] : ["PLAYER 2", "Black — Shadow Mage"]);
    card.dataset.color = color;
    card.querySelector(".name").textContent = name;
    card.querySelector(".role").textContent = role;
    card.querySelector(".avatar").textContent = color === "w" ? "♞︎" : "♛︎";
    card.classList.toggle("active", !over && t === color);
    const taken = caps[color].sort((a, b) => VALUE[b] - VALUE[a]);
    card.querySelector(".caps").innerHTML = taken.map(p => `<span class="${color === "w" ? "cb" : "cw"}">${GLYPH[p]}︎</span>`).join("");
  });
  $("#undoBtn").disabled = state.busy || !hist.length;
}

/* ---------- interaction ---------- */
function onSquare(sq) {
  if (state.busy || game.isGameOver() || !humanTurn()) return;
  if (state.sel && state.moves.some(m => m.to === sq)) return tryMove(state.sel, sq);
  const p = game.get(sq);
  if (p && p.color === game.turn()) { select(sq); sfx.click(); }
  else clearSel();
}

function select(sq) {
  state.sel = sq;
  state.moves = game.moves({ square: sq, verbose: true });
  mark();
}
function clearSel() { state.sel = null; state.moves = []; mark(); }

function setupDrag() {
  const board = $("#board");
  board.addEventListener("dragstart", e => {
    const sq = e.target.closest(".sq");
    const p = sq && game.get(sq.dataset.sq);
    if (state.busy || game.isGameOver() || !humanTurn() || !p || p.color !== game.turn()) return e.preventDefault();
    e.dataTransfer.setData("text/plain", sq.dataset.sq);
    e.dataTransfer.effectAllowed = "move";
    select(sq.dataset.sq);
  });
  board.addEventListener("dragover", e => {
    const sq = e.target.closest(".sq");
    if (sq && state.moves.some(m => m.to === sq.dataset.sq)) e.preventDefault();
  });
  board.addEventListener("drop", e => {
    e.preventDefault();
    const sq = e.target.closest(".sq");
    if (sq && state.sel && state.moves.some(m => m.to === sq.dataset.sq)) tryMove(state.sel, sq.dataset.sq);
  });
}

async function tryMove(from, to) {
  const options = state.moves.filter(m => m.to === to);
  if (!options.length) return;
  let promotion;
  if (options[0].promotion) {
    promotion = await askPromotion(game.turn());
    if (!promotion) return clearSel();
  }
  doMove(from, to, promotion);
}

function askPromotion(color) {
  return new Promise(resolve => {
    const modal = $("#promo"), box = $("#promoChoices");
    box.innerHTML = ["q", "r", "b", "n"].map(p =>
      `<button class="btn" data-p="${p}" aria-label="${NAMES[p]}"><span class="pc ghost-less ${color}" style="font-size:2.4rem;position:static;display:block;animation:none">${GLYPH[p]}︎</span></button>`).join("");
    modal.hidden = false;
    modal.onclick = e => {
      const b = e.target.closest("button");
      if (!b && e.target !== modal) return;
      modal.hidden = true;
      resolve(b ? b.dataset.p : null);
    };
  });
}

/* ---------- making a move ---------- */
async function doMove(from, to, promotion) {
  const gen = state.gen;
  state.busy = true;
  clearSel();
  const move = game.move({ from, to, promotion });
  state.last = [from, to];
  updatePanel();
  await animateMove(move);
  if (gen !== state.gen) return;
  afterMove(move);
}

function afterMove() {
  renderAll();
  const loser = game.turn() === "w" ? "Black" : "White", winner = loser === "White" ? "Black" : "White";
  if (game.isCheckmate()) {
    sfx.mate();
    for (let i = 0; i < 6; i++) setTimeout(() => hit("q", Math.floor(rnd(0, 8)), Math.floor(rnd(0, 8))), i * 220);
    setTimeout(() => showEnd("CHECKMATE", `${winner} wins the battle.`), 900);
    state.busy = false;
    return;
  }
  if (game.isGameOver()) {
    showEnd(game.isStalemate() ? "STALEMATE" : "DRAW", "The battle ends without a victor.");
    state.busy = false;
    return;
  }
  if (game.isCheck()) { sfx.check(); toast("KING UNDER ATTACK"); }
  if (state.mode === "ai" && game.turn() === "b") aiTurn();
  else { state.busy = false; updatePanel(); }
}

function showEnd(title, text) {
  $("#endTitle").textContent = title;
  $("#endText").textContent = text;
  $("#end").hidden = false;
}

function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast.id);
  toast.id = setTimeout(() => t.classList.remove("show"), 1800);
}

function newGame() {
  state.gen++;
  game.reset();
  Object.assign(state, { sel: null, moves: [], busy: false, last: null, anim: null });
  $("#fx").textContent = "";
  $("#end").hidden = true;
  $("#promo").hidden = true;
  $("#thinking").hidden = true;
  renderAll();
}

function undo() {
  if (state.busy || !game.history().length) return;
  state.gen++;
  game.undo();
  if (state.mode === "ai" && game.turn() === "b" && game.history().length) game.undo();
  const h = game.history({ verbose: true }), m = h[h.length - 1];
  state.last = m ? [m.from, m.to] : null;
  $("#end").hidden = true;
  clearSel();
  renderAll();
}

/* ---------- animation ---------- */
async function animateMove(m) {
  const victimSq = m.flags.includes("e") ? m.to[0] + m.from[1] : m.to;
  const hide = new Set([m.to]), show = {};
  if (m.captured) { hide.add(victimSq); show[victimSq] = { type: m.captured, color: m.color === "w" ? "b" : "w" }; }
  let rook = null;
  if (m.flags.includes("k") || m.flags.includes("q")) {
    const rank = m.to[1];
    rook = m.flags.includes("k") ? { from: "h" + rank, to: "f" + rank } : { from: "a" + rank, to: "d" + rank };
    hide.add(rook.to);
  }
  state.anim = { hide, show };
  renderBoard();
  const runs = [slide(m.color, m.piece, m.from, m.to)];
  if (rook) runs.push(slide(m.color, "r", rook.from, rook.to));
  await Promise.all(runs);
  if (m.captured) await battle(m, victimSq);
  sfx.move();
  state.anim = null;
  renderBoard();
  $("#fx").querySelectorAll(".ghost").forEach(g => g.remove());
}

function pathOf(from, to, type) {
  const [c1, r1] = disp(from), [c2, r2] = disp(to);
  if (type === "n") return [[c1, r1], [c2, r2]];
  const n = Math.max(Math.abs(c2 - c1), Math.abs(r2 - r1)), dc = Math.sign(c2 - c1), dr = Math.sign(r2 - r1);
  return Array.from({ length: n + 1 }, (_, i) => [c1 + dc * i, r1 + dr * i]);
}

// each square along the way is a separate keyframe, so the piece visibly steps
function slide(color, type, from, to) {
  const pts = pathOf(from, to, type), knight = type === "n";
  const g = document.createElement("span");
  g.className = `pc ghost ${color}`;
  g.textContent = GLYPH[type] + "\uFE0E";
  const at = (c, r, extra = "") => `translate(${c * 100}%,${r * 100}%) ${extra}`;
  let frames;
  if (knight) {
    const [a, b] = pts;
    frames = [
      { transform: at(a[0], a[1]) },
      { transform: at((a[0] + b[0]) / 2, (a[1] + b[1]) / 2 - 0.9, "scale(1.5) rotate(14deg)") },
      { transform: at(b[0], b[1]) }
    ];
  } else {
    frames = pts.map(([c, r], i) => ({
      transform: at(c, r, i === 0 || i === pts.length - 1 ? "" : `scale(1.15) rotate(${i % 2 ? 5 : -5}deg)`)
    }));
  }
  g.style.transform = frames[0].transform;
  $("#fx").append(g);
  const steps = pts.length - 1;
  const dur = knight ? 650 : Math.min(1000, Math.max(420, steps * 240));
  pts.forEach(([c, r], i) => setTimeout(() => step(c, r), (dur * i / steps) * 0.92));
  if (knight) sfx.whoosh();
  const a = g.animate(frames.map(f => ({ ...f, easing: "ease-in-out" })), { duration: dur, fill: "forwards" });
  return a.finished;
}

async function battle(m, victimSq) {
  const [c, r] = disp(victimSq);
  const victim = document.querySelector(`[data-sq="${victimSq}"] .pc`);
  const attacker = document.querySelector("#fx .ghost");
  victim?.animate([{ translate: "0 0" }, { translate: "-7% 0" }, { translate: "7% 0" }, { translate: "0 0" }], { duration: 160 });
  await wait(130);
  hit(m.piece, c, r);
  float(`${NAMES[m.piece]} ${VERBS[m.piece]} ${NAMES[m.captured]}!`, c, r);
  attacker?.animate([{ scale: 1 }, { scale: 1.4 }, { scale: 1 }], { duration: 320 });
  victim?.animate([{ opacity: 1, scale: 1 }, { opacity: 0, scale: 0.3, rotate: "40deg" }], { duration: 380, fill: "forwards" });
  await wait(440);
}

function cell(c, r) {
  const d = document.createElement("div");
  d.className = "cell";
  d.style.left = c * 12.5 + "%";
  d.style.top = r * 12.5 + "%";
  $("#fx").append(d);
  return d;
}

function step(c, r) {
  const d = cell(c, r);
  d.innerHTML = '<span class="fxe step"></span>';
  setTimeout(() => d.remove(), 950);
}

function float(text, c, r) {
  const d = cell(c, r);
  d.innerHTML = `<span class="float">${text}</span>`;
  setTimeout(() => d.remove(), 1400);
}

function hit(type, c, r) {
  const d = cell(c, r);
  d.innerHTML = FX[type].map(cls => `<span class="fxe ${cls}"></span>`).join("");
  for (let i = 0; i < 10; i++) {
    const s = document.createElement("span");
    s.className = "spark";
    d.append(s);
    const a = rnd(0, Math.PI * 2), dist = rnd(30, 90);
    s.animate([{ transform: "translate(0,0)", opacity: 1 }, { transform: `translate(${Math.cos(a) * dist}%,${Math.sin(a) * dist}%)`, opacity: 0 }], { duration: rnd(350, 650), easing: "ease-out" });
  }
  const frame = $("#frame");
  frame.classList.remove("shake"); void frame.offsetWidth; frame.classList.add("shake");
  ({ p: sfx.slash, n: sfx.slash, b: sfx.magic, q: sfx.magic, r: sfx.boom, k: sfx.boom })[type]();
  setTimeout(() => d.remove(), 1000);
}

/* ---------- AI ---------- */
function aiTurn() {
  const gen = state.gen;
  state.busy = true;
  $("#thinking").hidden = false;
  updatePanel();
  setTimeout(() => {
    if (gen !== state.gen) return;
    const m = pickMove();
    $("#thinking").hidden = true;
    if (!m) { state.busy = false; return; }
    doMove(m.from, m.to, m.promotion);
  }, 700);
}

function pickMove() {
  const moves = ordered(game.moves({ verbose: true }));
  let best = null, bestScore = -Infinity;
  for (const m of moves) {
    play(m);
    const score = -search(2, -Infinity, Infinity) + rnd(0, 6);
    game.undo();
    if (score > bestScore) { bestScore = score; best = m; }
  }
  return best;
}

const play = m => game.move({ from: m.from, to: m.to, promotion: m.promotion });

function ordered(moves) {
  const score = m => (m.captured ? VALUE[m.captured] * 10 - VALUE[m.piece] : 0) + (m.promotion ? 800 : 0) + (m.san.includes("+") ? 50 : 0);
  return moves.sort((a, b) => score(b) - score(a));
}

// negamax with alpha-beta; score is from the side to move
function search(depth, alpha, beta) {
  const moves = game.moves({ verbose: true });
  if (!moves.length) return game.isCheck() ? -50000 - depth : 0;
  if (depth === 0) return quiet(alpha, beta, 2);
  for (const m of ordered(moves)) {
    play(m);
    const s = -search(depth - 1, -beta, -alpha);
    game.undo();
    if (s >= beta) return beta;
    if (s > alpha) alpha = s;
  }
  return alpha;
}

// only look at captures at the horizon so it doesn't walk into recaptures
function quiet(alpha, beta, depth) {
  const stand = evaluate();
  if (stand >= beta) return beta;
  if (depth === 0) return Math.max(stand, alpha);
  if (stand > alpha) alpha = stand;
  for (const m of ordered(game.moves({ verbose: true }).filter(x => x.captured))) {
    play(m);
    const s = -quiet(-beta, -alpha, depth - 1);
    game.undo();
    if (s >= beta) return beta;
    if (s > alpha) alpha = s;
  }
  return alpha;
}

function evaluate() {
  let s = 0;
  game.board().forEach((row, r) => row.forEach((p, c) => {
    if (!p) return;
    const center = (3 - Math.abs(c - 3.5) + 0.5) + (3 - Math.abs(r - 3.5) + 0.5);
    let v = VALUE[p.type];
    if (p.type === "p") v += center * 2 + (p.color === "w" ? 6 - r : r - 1) * 7;
    else if (p.type === "n" || p.type === "b") v += center * 5;
    else if (p.type === "q") v += center;
    else if (p.type === "k") v -= center * 4;
    s += p.color === "w" ? v : -v;
  }));
  if (game.isCheck()) s += game.turn() === "w" ? -35 : 35;
  return game.turn() === "w" ? s : -s;
}

/* ---------- sound (Web Audio, no files) ---------- */
let ac;
function tone(f, d = 0.12, type = "sine", to = f, vol = 0.07, delay = 0) {
  if (!state.sound) return;
  try {
    ac = ac || new (window.AudioContext || window.webkitAudioContext)();
    const t = ac.currentTime + delay, o = ac.createOscillator(), g = ac.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(to, 20), t + d);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + d);
    o.connect(g).connect(ac.destination);
    o.start(t); o.stop(t + d);
  } catch (e) { /* audio unavailable, game still works */ }
}
const sfx = {
  click: () => tone(520, 0.05, "square", 720, 0.03),
  move: () => tone(190, 0.09, "triangle", 120),
  whoosh: () => tone(300, 0.4, "sine", 900, 0.04),
  slash: () => { tone(1400, 0.16, "sawtooth", 250, 0.05); tone(180, 0.2, "square", 80, 0.05, 0.05); },
  magic: () => { tone(300, 0.45, "sine", 1100, 0.07); tone(450, 0.45, "triangle", 1500, 0.04, 0.05); },
  boom: () => { tone(110, 0.4, "sawtooth", 30, 0.12); tone(1100, 0.12, "square", 300, 0.04); },
  check: () => { tone(660, 0.15, "square", 660, 0.05); tone(520, 0.25, "square", 520, 0.05, 0.18); },
  mate: () => [392, 330, 262, 196].forEach((f, i) => tone(f, 0.45, "triangle", f * 0.97, 0.07, i * 0.22))
};

/* ---------- background ---------- */
function buildForest() {
  // pine silhouettes drawn as an SVG tile, tiled horizontally by CSS
  const pine = (x, h) => {
    const k = h / 320, p = [[0, 20], [28, 110], [14, 110], [38, 190], [16, 190], [46, 280], [6, 280], [6, 320]];
    const right = p.map(([a, b]) => [x + a * k, 320 - (320 - b) * k]);
    const left = p.slice().reverse().map(([a, b]) => [x - a * k, 320 - (320 - b) * k]);
    return `<polygon points="${[...right, ...left].map(q => q.map(n => n.toFixed(1)).join(",")).join(" ")}"/>`;
  };
  const layer = (color, n, min, max, seed) => {
    let s = seed, rand = () => (s = (s * 16807) % 2147483647) / 2147483647, trees = "";
    for (let i = 0; i < n; i++) trees += pine(30 + (1140 / n) * i + rand() * 30, min + rand() * (max - min));
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="320" viewBox="0 0 1200 320" preserveAspectRatio="none"><g fill="${color}">${trees}</g></svg>`;
    return `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
  };
  const root = document.documentElement.style;
  root.setProperty("--t1", layer("#2a1458", 16, 150, 260, 7));
  root.setProperty("--t2", layer("#150a32", 12, 190, 300, 13));
  root.setProperty("--t3", layer("#06020f", 8, 230, 330, 29));
  const flies = $("#flies");
  for (let i = 0; i < 26; i++) {
    const s = document.createElement("span");
    s.style.cssText = `left:${rnd(2, 98)}%;top:${rnd(35, 95)}%;--d:${rnd(6, 13)}s;--w:${-rnd(0, 10)}s;--x:${rnd(-60, 60)}px;--y:${rnd(-70, 30)}px`;
    flies.append(s);
  }
}
